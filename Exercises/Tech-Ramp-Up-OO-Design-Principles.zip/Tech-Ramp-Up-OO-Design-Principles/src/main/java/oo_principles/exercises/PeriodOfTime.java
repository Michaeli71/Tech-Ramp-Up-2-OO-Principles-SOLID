package oo_principles.exercises;

import java.util.Date;
import java.util.Objects;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public final class PeriodOfTime
{
    private final Date start;

    private Date       end;

    public PeriodOfTime(final Date start, final Date end)
    {
        Objects.requireNonNull(start, "start must not be null");
        Objects.requireNonNull(end, "end must not be null");

        if (start.after(end))
            throw new IllegalArgumentException(start + " must be <= " + end);

        this.start = start;
        this.end = end;
    }

    public Date getStart()
    {
        return start;
    }

    public Date getEnd()
    {
        return end;
    }

    public void withNewEnd(final Date newEnd)
    {
        if (start.after(newEnd))
            throw new IllegalArgumentException(newEnd + " must be >= " + start);

        this.end = newEnd;
    }
}