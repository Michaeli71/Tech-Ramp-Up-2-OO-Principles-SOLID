package slides.oo_principles;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class ImmutableSurprise
{
    private final int          id;

    private final int[]        values;

    private final List<String> additionalValues;

    public ImmutableSurprise(int id, int[] values, List<String> additionalValues)
    {
        // Prüfungen ausgelassen

        this.id = id;
        this.values = values;
        this.additionalValues = additionalValues;
    }

    public int getId()
    {
        return id;
    }

    public int[] getValues()
    {
        return values;
    }

    public List<String> getAdditionalValues()
    {
        return additionalValues;
    }

    @Override
    public String toString()
    {
        return "ImmutableSurprise [id=" + id + ", values=" + Arrays.toString(values) + ", additionalValues="
               + additionalValues + "]";
    }

    public static void main(final String[] args)
    {
        final List<String> values = new ArrayList<>(List.of("Tim", "Tom", "Mike"));
        ImmutableSurprise is = new ImmutableSurprise(42, new int[] { 1, 2, 3 }, values);

        System.out.println(is);

        is.getValues()[1] = -123;
        is.getAdditionalValues().add("UNEXPECTED");

        System.out.println(is);
    }

}
