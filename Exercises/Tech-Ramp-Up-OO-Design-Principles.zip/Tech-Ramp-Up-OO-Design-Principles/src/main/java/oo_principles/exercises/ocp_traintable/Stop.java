package oo_principles.exercises.ocp_traintable;

/**
* Stop of a train in a station.
*/
public interface Stop
{
    /**
    * @return true if this is a departure stop where passengers can get on.
    */
    public boolean isStopToGetOn();

    /**
    * @return true if this is an arrival stop where passengers can get off.
    */
    public boolean isStopToGetOff();

    /**
    * @return the code string of the station this stop is for (this is the
    * unique string representing the station).
    */
    public String getStationCode();

    /**
    * @return the departure time in format "hh:mm" with leading zeroes.
    */
    public String getDepartureTime();

    /**
    * @return the arrival time in format "hh:mm" with leading zeroes.
    */
    public String getArrivalTime();
}