package oo_principles.solutions;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class SquareTest
{
    @Test
    public void testCalcArea()
    {
        final Rectangle r = new Rectangle(10, 20);
        assertEquals(200, r.computeArea());

        final Rectangle r2 = new Rectangle(10, 10);
        assertEquals(100, r2.computeArea());
        
        final Rectangle s = new Square(10);
        assertEquals(100, s.computeArea());
    }
}
