package slides.oo_principles.dip;

public class Customer {

}
