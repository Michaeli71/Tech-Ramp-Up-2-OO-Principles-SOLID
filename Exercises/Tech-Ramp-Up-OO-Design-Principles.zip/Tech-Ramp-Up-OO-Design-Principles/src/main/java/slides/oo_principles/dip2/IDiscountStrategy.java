package slides.oo_principles.dip2;

import slides.oo_principles.dip.Pizza;

public interface IDiscountStrategy
{
    public double apply(Pizza pizza);
}
