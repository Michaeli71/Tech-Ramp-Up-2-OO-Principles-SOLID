package slides.oo_principles.dip;

import java.util.ArrayList;
import java.util.List;

public class Receipt 
{
	private final List<Pair<Pizza, Double>> pizzasAndPrices = new ArrayList<>();
	private final Customer customer;
	private boolean payed = false;

	public Receipt(Customer customer) 
	{
		this.customer = customer;
	}

	public void addEntry(Pizza pizza, double price) 
	{
		pizzasAndPrices.add(new Pair<>(pizza, price));
	}

	public List<Pair<Pizza, Double>> getOrders() 
	{
		return pizzasAndPrices;
	}

	public void setPayed(boolean payed) {
		this.payed = payed;
	}

	public boolean isPayed()
	{
		return payed;
	}

	public double total()
	{
		return getOrders().stream().map(p -> p.getSecond()).mapToDouble(i->i).sum();
	}
}
