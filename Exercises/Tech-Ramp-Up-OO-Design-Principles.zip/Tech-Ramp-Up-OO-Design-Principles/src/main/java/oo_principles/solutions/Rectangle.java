package oo_principles.solutions;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Rectangle
{
    // LSP: Attribute sind final und damit unveränderlich
    // LSP: Keine set()-Methoden, dadurch kann aus einem Rechteck kein Quadrat werden
    private final int height;
    private final int width;

    public Rectangle(int height, int width)
    {
        this.height = height;
        this.width = width;
    }

    public int computeArea()
    {
        return this.height * this.width;
    }

    public int getHeight()
    {
        return this.height;
    }

    public int getWidth()
    {
        return this.width;
    }
}
