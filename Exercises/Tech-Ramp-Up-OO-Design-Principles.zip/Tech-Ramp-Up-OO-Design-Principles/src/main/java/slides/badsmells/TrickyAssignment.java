package slides.badsmells;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class TrickyAssignment
{
    public static void main(String[] args)
    {
        int trickyPre = 0;
        int trickyPost = 0;
        for (int i = 0; i < 50; i++)
        {
            trickyPre += ++trickyPre;
            trickyPost += trickyPost++;
        }
        System.out.println("trickyPre = " + trickyPre + " / " + "trickyPost = " + trickyPost);
    }
}
