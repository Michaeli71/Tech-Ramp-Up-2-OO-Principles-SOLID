package oo_principles.solutions;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class RectangleSquareTest
{
    @Test
    public void testCalcArea()
    {
        final RectangleSquare_NoInheritence r = new RectangleSquare_NoInheritence(10, 20);
        assertEquals(200, r.computeArea());
        assertFalse(r.isSquare());

        // selbst Modifikationen möglich und keine Typänderung nötig
        // Quadrateigenschaft ergibt sich aus den Seitenlängen
        r.setHeight(20);
        assertEquals(400, r.computeArea());
        assertTrue(r.isSquare());
        
        final RectangleSquare_NoInheritence r2 = new RectangleSquare_NoInheritence(10, 10);
        assertEquals(100, r2.computeArea());
        assertTrue(r2.isSquare());        
    }
}
