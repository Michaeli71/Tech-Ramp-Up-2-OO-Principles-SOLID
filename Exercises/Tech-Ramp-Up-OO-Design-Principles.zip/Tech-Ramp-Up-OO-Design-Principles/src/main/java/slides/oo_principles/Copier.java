package slides.oo_principles;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Copier
{
    public boolean writeConsole = false;

    public void copy()
    {
        int ch = Keyboard.read();

        while (ch != -1)
        {
            if (writeConsole)
                Console.write(ch);
            else
                Printer.write(ch);

            ch = Keyboard.read();
        }
    }
}