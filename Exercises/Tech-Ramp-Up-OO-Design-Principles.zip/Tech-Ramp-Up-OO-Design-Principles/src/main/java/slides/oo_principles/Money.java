package slides.oo_principles;

import java.util.Currency;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
class Money
{
    private final double   amount;
    private final Currency currency;

    public Money(double amount, Currency currency)
    {
        this.amount = amount;
        this.currency = currency;
    }

    public Currency getCurrency()
    {
        return currency;
    }

    public double getAmount()
    {
        return amount;
    }
}