package oo_principles.solutions;

import java.util.Date;
import java.util.Objects;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class ImmutablePeriodOfTime
{
    private final Date start;
    private Date       end;
    
    public ImmutablePeriodOfTime(final Date start, final Date end)
    {
        Objects.requireNonNull(start, "start must not be null");
        Objects.requireNonNull(end, "end must not be null");
        
        if (start.after(end))
            throw new IllegalArgumentException(end + " must be >= " + start);

        this.start = new Date(start.getTime());
        this.end = new Date(end.getTime());
    }
    
    public Date getStart()
    {
        return new Date(start.getTime());
    }

    public Date getEnd()
    {
        return new Date(end.getTime());
    }
    
    public void withNewEnd(final Date newEnd)
    {
        if (start.after(newEnd))
            throw new IllegalArgumentException(newEnd + " must be >= " + start);

        this.end = newEnd;
    }

    @Override
    public String toString()
    {
        return "ImmutablePeriodOfTime [start=" + start + ", end=" + end + "]";
    }
    
    public static void main(String[] args)
    {
        final Date start = new Date(1_000_000_000_000L);
        final Date end = new Date(1_234_000_000_000L);
        final ImmutablePeriodOfTime period = new ImmutablePeriodOfTime(start, end);
        
        // Probieren wir es erneut:
        // =======================
        
        // Invariante (start <= end) von PeriodOfTime wird durch setTime(700) NICHT MEHR verletzt
        System.out.println("period: " + period);
        end.setTime(700);
        System.out.println("period: " + period);
        
        // noch überraschender: Änderung im Objekt, ändert WEDER die Variable NOCH im Objekt
        System.out.println("start: " + start);
        period.getStart().setTime(0);   // liefert jetzt Kopie, nicht Zugriff auf das Attribute
        System.out.println("period: " + period);
        System.out.println("start: " + start);
    }  
}
