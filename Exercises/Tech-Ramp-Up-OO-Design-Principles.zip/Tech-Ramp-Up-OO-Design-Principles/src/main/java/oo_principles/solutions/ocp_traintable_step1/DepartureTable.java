package oo_principles.solutions.ocp_traintable_step1;

import java.util.ArrayList;
import java.util.List;


// Schritt 1: als Idee
// - man erkennt aber, dass der Klassename nicht mehr passt
// - die Datenspeicherung ist auch suboptimal
// - Wieso erfolgt die Berechnung im Konstruktor?
// - Was hat das für Konsequenzen?
/**
* Table of trains to display the relevant trains departing in a station.
*/
public class DepartureTable
{
    // Schritt 1: Weitere Variable und Fallunterscheidung untern
    private List<Train> departingTrains;
    private List<Train> arrivingTrains;

    /**
    * Initialize a departure table from a list of trains by filtering this list.
    *
    * @param trains the trains to use for the departure table (not yet filtered)
    * @param stationCode the code of the station for which to filter the trains
    */
    public DepartureTable(List<Train> trains, String stationCode)
    {
        departingTrains = new ArrayList<>();
        arrivingTrains = new ArrayList<>();

        for (Train train : trains)
        {
            if (train.isPublic())
            {
                Stop stop = train.getStop(stationCode);
                if (stop != null)
                {
                    // OCP Verstoß: Jede weitere Ergänzung würde wieder zu Code-Änderungen führen                    
                    if (stop.isStopToGetOn())
                    {
                        departingTrains.add(train);
                    }
                    if (stop.isStopToGetOff())
                    {
                        arrivingTrains.add(train);
                    }
                }
            }
        }
    }

    /**
    * @return all the trains to display in departure table.
    */
    public List<Train> getDepartingTrains()
    {
        return departingTrains;
    }
    
    public List<Train> getArrivingTrains()
    {
        return arrivingTrains;
    }
}