package slides.oo_principles.dip2;

import slides.oo_principles.dip.Pizza;

public class HalfPriceDiscountStrategy implements IDiscountStrategy
{
	public double apply(Pizza pizza)
	{
		return pizza.getPrice() *.5;
	}
}
