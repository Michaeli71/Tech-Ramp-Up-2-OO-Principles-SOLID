package slides.badsmells;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class TernaryOperatorTypeSurprise
{
    public static void main(String[] args)
    {
        boolean returnInt = true;
        Object val = returnInt ? 5 : 7.0;
        System.out.println("val is " + val + " of " + val.getClass());

        if (returnInt)
            val = 5;
        else
            val = 7.0;
        System.out.println("val is " + val + " : " + val.getClass());
    }
}
