package oo_principles.solutions;

import java.util.Date;
import java.util.Objects;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public final class PeriodOfTime
{
    private final Date start;

    private Date       end;

    public PeriodOfTime(final Date start, final Date end)
    {
        Objects.requireNonNull(start, "start must not be null");
        Objects.requireNonNull(end, "end must not be null");

        if (start.after(end))
            throw new IllegalArgumentException(start + " must be <= " + end);

        this.start = start;
        this.end = end;
    }

    public Date getStart()
    {
        return start;
    }

    public Date getEnd()
    {
        return end;
    }

    public void withNewEnd(final Date newEnd)
    {
        if (start.after(newEnd))
            throw new IllegalArgumentException(newEnd + " must be >= " + start);

        this.end = newEnd;
    }

    @Override
    public String toString()
    {
        return "PeriodOfTime [start=" + start + ", end=" + end + "]";
    }

    public static void main(String[] args)
    {
        final Date start = new Date(1_000_000_000_000L);
        final Date end = new Date(1_234_000_000_000L);
        final PeriodOfTime period = new PeriodOfTime(start, end);
        
        // Invariante (start <= end) von PeriodOfTime wird durch setTime(700) verletzt
        System.out.println("period: " + period);
        end.setTime(700);
        System.out.println("period: " + period);
        
        // noch überraschender: Änderung im Objekt, ändert auch die Variable
        System.out.println("start: " + start);
        period.getStart().setTime(0);
        System.out.println("period: " + period);
        System.out.println("start: " + start);
    }    
}