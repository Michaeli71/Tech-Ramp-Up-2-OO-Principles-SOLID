package slides.oo_principles.dip;

public class Discount 
{
	public double apply(Pizza pizza) 
	{
		return pizza.getPrice() *.9;
	}
}
