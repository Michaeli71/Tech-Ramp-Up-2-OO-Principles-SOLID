package oo_principles.exercises;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Square extends Rectangle
{
    public Square(int sideLength)
    {
        super(sideLength, sideLength);
    }

    protected void setSideLength(final int sideLength)
    {
        // gleiche Seitenlänge sicherstellen
        super.setHeight(sideLength);
        super.setWidth(sideLength);
    }

    // eigentlich würde man diese gerne verbieten ...
    @Override
    public void setHeight(int height) { setSideLength(height); }
    @Override
    public void setWidth(int width) { setSideLength(width); }
}
