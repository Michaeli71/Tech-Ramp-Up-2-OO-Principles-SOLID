package oo_principles.solutions.ocp_traintable_step3;

import java.util.ArrayList;
import java.util.List;

/**
* Table of trains to display the relevant trains departing in a station.
*/
public class TrainInfoTable
{
    private final String      stationCode;

    /**
    * Initialize a departure table from a list of trains by filtering this list.
    *
    * @param trains the trains to use for the departure table (not yet filtered)
    * @param stationCode the code of the station for which to filter the trains
    */
    public TrainInfoTable(String stationCode)
    {
        this.stationCode = stationCode;
    }

    /**
     * @return all the trains to display in departure table.
    */
    public List<Train> getDepartingTrains(List<Train> trains)
    {
        return getRelevantTrains(trains, stationCode, new DepartingStop());
    }

    public List<Train> getArrivingTrains(List<Train> trains)
    {
        return getRelevantTrains(trains, stationCode, new ArrivingStop());
    }

    // Neues Interface
    interface FilterCriteria
    {
        boolean accept(Stop stop);
    }

    // Neue Filter-Kriterien
    static class DepartingStop implements FilterCriteria
    {
        @Override
        public boolean accept(Stop stop)
        {
            return stop.isStopToGetOn();
        }
    }

    static class ArrivingStop implements FilterCriteria
    {
        @Override
        public boolean accept(Stop stop)
        {
            return stop.isStopToGetOff();
        }
    }

    private static List<Train> getRelevantTrains(List<Train> trains, String stationCode, 
                                                 FilterCriteria filterCriteria)
    {
        final List<Train> relevantTrains = new ArrayList<>();

        for (Train train : trains)
        {
            if (train.isPublic())
            {
                Stop stop = train.getStop(stationCode);
                if (stop != null)
                {
                    // OCP konfrom: Jede weitere (Stop-relevante) Ergänzung bedarf keine Code-Änderungen                     
                    if (filterCriteria.accept(stop))
                    {
                        relevantTrains.add(train);
                    }
                }
            }
        }
        
        return relevantTrains;
    }
}