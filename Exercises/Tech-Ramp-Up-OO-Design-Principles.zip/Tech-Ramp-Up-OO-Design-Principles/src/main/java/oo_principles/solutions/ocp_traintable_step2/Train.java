package oo_principles.solutions.ocp_traintable_step2;

/**
* Interface to Train objects as used in the Design Principles exercise.
*/
public interface Train
{
    /**
    * @param station code of the station to get the stop for.
    * @return the stop of this train at the queried station. Returns 'null' if
    * this train does not stop at the queried station.
    */
    public Stop getStop(String station);

    /**
    * @return true if train is public
    */
    public boolean isPublic();

    /**
    * @return special kind code for this train.
    *
    * Possible codes are:
    * <ul>
    * <li> "S" - Sonderzug, verkehrt nur an speziellen Tagen</li>
    * <li> "D" - Dispositionszug, verkehrt nur in speziellen Ausnahmefällen</li>
    * </ul>
    */
    public String getKind();
}