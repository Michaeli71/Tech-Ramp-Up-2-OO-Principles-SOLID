package slides.oo_principles;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Keyboard
{
    public static int read()
    {       
        return 0;
    }
}
