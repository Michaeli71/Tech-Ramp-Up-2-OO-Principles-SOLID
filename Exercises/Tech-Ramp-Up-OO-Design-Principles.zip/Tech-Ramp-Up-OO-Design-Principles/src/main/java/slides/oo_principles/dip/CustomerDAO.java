package slides.oo_principles.dip;

public class CustomerDAO {

	public Customer findById(long customerId) 
	{		
		return null;
	}
}
