package oo_principles.solutions;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Square extends Rectangle
{
    // LSP: keine Modifikationen möglich, damit immer gegeben
    public Square(int sideLength)
    {
        super(sideLength, sideLength);
    }
}