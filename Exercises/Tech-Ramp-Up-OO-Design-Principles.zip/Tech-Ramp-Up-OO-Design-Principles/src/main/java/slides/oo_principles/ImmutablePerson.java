package slides.oo_principles;

import java.time.LocalDate;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
class ImmutablePerson
{
    private final String name;
    private final LocalDate dateOfBirth;

    public ImmutablePerson(final String name, final LocalDate dateOfBirth)
    {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
    }

    public String getName()
    {
        return name;
    }

    public LocalDate getDateOfBirth()
    {
        return dateOfBirth;
    }    
}