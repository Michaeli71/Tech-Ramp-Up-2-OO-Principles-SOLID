package oo_principles.exercises;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class RectangleTest
{
    @Test
    void testAreaCalulaction()
    {
        Rectangle rect = new Rectangle(7, 6);
        
        rect.setWidth(5);
        rect.setHeight(10);

        assertEquals(50, rect.computeArea());
    }
}
