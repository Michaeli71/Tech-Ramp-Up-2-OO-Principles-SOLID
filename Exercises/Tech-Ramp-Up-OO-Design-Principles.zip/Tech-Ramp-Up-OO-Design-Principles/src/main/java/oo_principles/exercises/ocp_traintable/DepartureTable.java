package oo_principles.exercises.ocp_traintable;

import java.util.ArrayList;
import java.util.List;

/**
* Table of trains to display the relevant trains departing in a station.
*/
public class DepartureTable
{
    private List<Train> departingTrains;

    /**
    * Initialize a departure table from a list of trains by filtering this list.
    *
    * @param trains the trains to use for the departure table (not yet filtered)
    * @param stationCode the code of the station for which to filter the trains
    */
    public DepartureTable(List<Train> trains, String stationCode)
    {
        departingTrains = new ArrayList<>();
        for (Train train : trains)
        {
            if (train.isPublic())
            {
                Stop stop = train.getStop(stationCode);
                if (stop != null)
                {
                    if (stop.isStopToGetOn())
                    {
                        departingTrains.add(train);
                    }
                }
            }
        }
    }

    /**
    * @return all the trains to display in departure table.
    */
    public List<Train> getDepartingTrains()
    {
        return departingTrains;
    }
}