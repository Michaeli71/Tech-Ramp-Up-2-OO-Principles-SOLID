package slides.oo_principles.dip2;

import java.util.HashMap;
import java.util.Map;

import slides.oo_principles.dip.Customer;
import slides.oo_principles.dip.CustomerDAO;
import slides.oo_principles.dip.Pizza;
import slides.oo_principles.dip.Receipt;

public class PizzaService
{
	private final CustomerDAO customerDAO;

	private Map<Long, Receipt> customerToReceipt = new HashMap<>();

	public PizzaService(final CustomerDAO customerDAO)
	{
		this.customerDAO = customerDAO;
	}

	public void orderPizza(final long customerId, final Pizza pizza,
						   final IDiscountStrategy discountStrategy)
	{
		final Customer customer = customerDAO.findById(customerId);
		customerToReceipt.putIfAbsent(customerId, new Receipt(customer));
		
		final Receipt receipt = customerToReceipt.get(customerId);
		final double price = discountStrategy.apply(pizza);
		receipt.addEntry(pizza, price);
	}

	public void printReceipt(final long customerId)
	{
		final Receipt receipt = customerToReceipt.get(customerId);
		System.out.println("Receipt for Customer " + customerId);
		receipt.getOrders().forEach(System.out::println);

		if (receipt.isPayed())
			System.out.println("Already payed");
		else
			System.out.println("To pay: " + receipt.total());
	}
	
	public void deliverPizza(final long customerId)
	{
		final Receipt receipt = customerToReceipt.get(customerId);
		receipt.setPayed(true);
	}
	
	public static void main(String[] args) 
	{
		final PizzaService pizzaService = new PizzaService(new CustomerDAO());
		pizzaService.orderPizza(2, new Pizza("Diavolo", 10), new HalfPriceDiscountStrategy());
		pizzaService.orderPizza(2, new Pizza("Surprise", 15), new TenPrecentDiscountStrategy());

		pizzaService.printReceipt(2);
		pizzaService.deliverPizza(2);
		pizzaService.printReceipt(2);
	}
}