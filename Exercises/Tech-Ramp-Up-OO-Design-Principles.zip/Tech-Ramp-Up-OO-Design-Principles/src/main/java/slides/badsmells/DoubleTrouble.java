package slides.badsmells;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class DoubleTrouble
{
    public static void main(String[] args)
    {
        Double res1a = specialComplicatedTernaryOp(null, 4711d);
        System.out.println("Value " + res1a);

        Double res1b = specialComplicatedTernaryOpSimpler(null, 4711d);
        System.out.println("Value " + res1b);

        
        Double res2a = specialComplicatedTernaryOp(null, null);
        System.out.println("Value " + res2a);
        
        Double res2b = specialComplicatedTernaryOpSimpler(null, null);
        System.out.println("Value " + res2b);

    }

    private static Double specialComplicatedTernaryOp(Double value1, Double value2)
    {
        Double value = value1 == null ? value2 : value2 == null ? value1 : new Double(value1 + value2);
        return value;
    }

    private static Double specialComplicatedTernaryOpSimpler(Double value1, Double value2)
    {
        Double value = value1 == null ? value2 : value2 == null ? value1 : value1 + value2;
        return value;
    }
}
